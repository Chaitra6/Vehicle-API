package com.udacity.pricing.domain.price;

// Defines Enumeration for currency for easy use
public enum CurrencyEnum {
    INR,
    USD
}
