package com.udacity.pricing;

import com.udacity.pricing.domain.price.CurrencyEnum;
import com.udacity.pricing.domain.price.Price;
import com.udacity.pricing.domain.price.PriceRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class PricingServiceApplicationTests {

//	protected Price price;
//	protected BigDecimal expectedValue = new BigDecimal(10.50);

	@Autowired
	PriceRepository priceRepo;

	@Autowired
	MockMvc mvc ;



	@Test
	public void contextLoads() {
	}

//


	@Test
	public void testFindPrice() {
		try{
			mvc.perform(get("/prices/11").accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk());

		}catch (Exception ex){
			throw  new RuntimeException(ex.getCause() +" : "+ex.getLocalizedMessage());
		}
	}


	@Test
	public void testFindByVehID(){
		// Optional contains null or non-null value.
		// If value isPresent, assert is true else false
		Optional<Price> optionalPrice = priceRepo.findById(13L);

		assertTrue(optionalPrice.isPresent());
	}

	@Test
	public void testFindAll(){
		List<Price> prices = (List<Price>) priceRepo.findAll();

		// At 0th index of JSON Vehicle ID is 11
		assertEquals(11, prices.get(0).getVehicleId().intValue());

		// At 2nd index of JSON Vehicle ID is 13
		assertEquals(13, prices.get(2).getVehicleId().intValue());

		// Expected 4 because I have added 4 items in prices.json
		assertEquals(5, prices.size());
	}


	// Delete
	@Test
	public void testDelete(){
		Long vehID = 16L;
		// Add a new price
		priceRepo.save(new Price(CurrencyEnum.INR, new BigDecimal(66), vehID));

		// get the price that we just added
		Price checkPrice = priceRepo.findById(vehID).get();

		// check for assertion
		assertThat(checkPrice.getVehicleId()).isEqualTo(vehID);

		// Delete the newly created Price
		priceRepo.delete(checkPrice);

		// try to get the price that we just added
		Optional<Price> checkPrice2 = priceRepo.findById(vehID);

		assertFalse(checkPrice2.isPresent());
	}
}
